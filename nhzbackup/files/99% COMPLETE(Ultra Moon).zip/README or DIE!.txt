Place this save to:
\user\sdmc\Nintendo 3DS\00000000000000000000000000000000\00000000000000000000000000000000\title\00040000\001B5100\data\00000001

This is a Pokemon Ultra Moon save!
Save file by Miguel92398
Subscribe to my channel: youtube.com/user/Miguel92398