DSEmu 0.4.10
============

DSEmu is an open source Nintendo DS emulator originally written by
Imran Nazar and now maintained by Chris Double.

It is incomplete but is able to run many of the homebrew Nintendo DS
programs available. It does not run any commercial Nintendo DS games.

NOTE:

- Workaround for 'console scramble'. There has been an issue since
  DevkitPro R14 which causes text output using the console output
  routines to be scrambled. I implemented a workaround in 0.4.6 but it
  didn't work for homebrew programs built with previous versions. I've
  been unable to fix the problem so far, so I added a 'Unscramble
  console text' option in the Options/Configuration menu option. If
  you run a game and the text appears scrambled, check or uncheck
  this, and it should correct the problem when you press 'Ok'. 

New features in 0.4.10 are:

- Sprite support fixed. Homebrew demos with sprites should now start
  to work.
- Support for some 8 bit graphics modes with palletes.
- Fixed crash that occurred occasionally in mode 5 rendering.
- Workaround for a thumb emulation bug that occurs with devkitpro r17 
  compiled programs (to be fixed properly in 0.4.11).
 
New features in 0.4.9 are:

- Fixed Thumb emulation bug the was occasionally causing black
  screens and crashes.
- Fixed touchscreen bug that prevented it from working with
  devkitpro release 17.
- Fixed even more SWI divide bugs with patch by Mark Winney.
- Fixed some bugs in DMA and SWI divide handling allowing
  a few more games to run (Ruby video demo, Tickle Girl, etc).

New features in 0.4.8 are:

- Support for the X and Y keys have been added. This can be configured
  using the Options/Configuration menu option. The code for this was
  contributed by Normmatt.
- Many fixes to key handling. Anything but A and B keys were very
  buggy in previous builds. My 'keys' demo from my tutorials now works
  correctly and Space Invaders is now playable.
- Support for GBA games was re-added. It was removed when I first took
  up support of DSEmu until I understood the code better. It is now
  back in and will be maintained.
- The FIFO registers have been implemented. This is an important
  feature for DSLinux and a step towards support for the commercial
  downloadable demos.
- Various bug fixes in graphics code.
- The compuational accelerator registers have been implemented. Again,
  a steps towards support for the commerical downloadable
  demos. Contributed by Julien Hamaide.
- Workaround for 'console scramble'. There has been an issue since
  DevkitPro R14 which causes text output using the console output
  routines to be scrambled. I implemented a workaround in 0.4.6 but it
  didn't work for homebrew programs built with previous versions. I've
  been unable to fix the problem so far, so I added a 'Unscramble
  console text' option in the Options/Configuration menu option. If
  you run a game and the text appears scrambled, check or uncheck
  this, and it should correct the problem when you press 'Ok'. I hope
  to fix this in 0.4.8.

DSEmu is open source and I welcome contributions. For more details see
the website: http://www.double.co.nz/nintendo_ds/dsemu.html

Chris Double
17 January 2006

