Fixes fake DSTT's destroyed by the official "fake-killer" firmware.

Contains the following files:

DsttFlashChecker.nds [ver 0.01] (determines whether your DSTT is a fake or not)
DsttFlashWriter.nds [ver 0.05] (re-flashes the fake DSTT destroyed by fake-killer)
DSTTDUMP.BIN (data that gets re-flashed by the DsttFlashWriter)
TTMENU.DAT (the official 1.17 firmware patched to disable fake-killer code).

If your DSTT is working, run DsttFlashChecker to see if it's a fake.

If you've determined that you have a fake DSTT and it has not yet been destroyed by the fake-killer firmware, use "TTMENU.DAT" in place of the official firmware to ensure that it will continue working properly (you will need to keep the TTMENU folder from the official firmware).

If your fake DSTT has been destroyed by the fake-killer firmware, but works intermittently, copy DsttFlashWriter.nds, DSTTDUMP.BIN, and TTMENU.DAT (replace the one from the official firmware) to the root of your microSD card, and run DsttFlashWriter from the menu. Press "A" to being the recovery. Restart and confirm that it now works properly. Once working properly, you can delete DsttFlashWriter.nds and DSTTDUMP.BIN from your microSD card, but leave TTMENU.DAT to replace the official firmware so that your fake DSTT doesn't get destroyed again.

If your fake DSTT doesn't work at all, you can recover it by running DsttFlashWriter on a working flash cart. Copy DsttFlashWriter.nds and DSTTDUMP.BIN to the root of the microSD card of the working flash cart, and run DsttFlashWriter on the working cart. Insert the non-working fake DSTT when prompted (no need to have a microSD card in the non-working flash cart at this point) and then press "A" to being the recovery. Before testing out the recovered fake DSTT, copy TTMENU.DAT to the microSD card of the fake DSTT (replace the one from the official firmware) to ensure that your fake DSTT doesn't get destroyed again. Once you've confirmed that the fake DSTT is working, you can delete DsttFlashWriter.nds and DSTTDUMP.BIN from the microSD card of the other flash cart.

USE AT YOUR OWN RISK!

