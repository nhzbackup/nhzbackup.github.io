﻿
Copie esta carpeta en la raíz de su tarjeta SD (no en el interior de la carpeta "/moonshl2") para activar la función Bloc de Notas.
Mantenga pulsado L o R y toque en la pantalla, o abra el menú del sistema con el botón START y seleccione "Abrir Bloc de Notas" para cargarlo.

Para obtener más información, por favor lea la ayuda.

~Traducido por Boriar