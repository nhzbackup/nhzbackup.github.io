# BNTX-Editor
A tool for editing Binary Resources Texture (BNTX) files

The tool is pretty straight forward, just run it and you will hopefully know what to do.

# Credits:
* AboodXD: Making this thing
* libtxc_dxtn: BC1/2/3 decompressors
* gdkchan: Helping with the relocation table