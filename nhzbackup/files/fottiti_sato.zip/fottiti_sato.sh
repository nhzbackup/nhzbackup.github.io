./ctrtool --contents=contents *.cia
mv *0 converted.cxi 
rm contents*