#include "mainstate.hpp"

#include <sys/stat.h>
#include <stdlib.h>

#include "savefile.hpp"
#include "options.hpp"
#include "resultstate.hpp"
#include "importstate.hpp"

MainState::MainState(sn::Gui* theGui) : sn::State(theGui) {
    //creating directory
    mkdir(BASE_PATH.c_str(), 0x777);

    //variable initialization
    save_selected = 0;

    //loading the external language file
    sn::Result res = gui_ptr->language_file.loadFromFile(BASE_ROMFS_PATH+"lang/eng.lang"); //loading english by default
    if( !res ) {
        initialization_result.setErrorNumber(ERR_LANGUAGE_FILE);
        initialization_result.setErrorDescription(res.getErrorDescription());
        return;
    }

    //texts initialization
    game_author.setFont(font_manager.getResource(BASE_ROMFS_PATH+"fonts/roboto.ttf"));
    game_author.setCharacterSize(35);

    game_title.setFont(font_manager.getResource(BASE_ROMFS_PATH+"fonts/roboto.ttf"));
    game_title.setCharacterSize(35);
    game_title.attachChild(&game_author);

    scene.addToLayer(&game_title, 0);

    arrow_info.setFont(font_manager.getResource(BASE_ROMFS_PATH+"fonts/roboto.ttf"));
    arrow_info.setMsg(gui_ptr->language_file.getValue("press_arrow_scroll"));
    arrow_info.setPosition(100, 600);

    export_info.setFont(font_manager.getResource(BASE_ROMFS_PATH+"fonts/roboto.ttf"));
    export_info.setMsg(gui_ptr->language_file.getValue("press_y_export"));
    arrow_info.attachChild(&export_info);
    export_info.setPosition(0, arrow_info.getSize().y + 10);

    import_info.setFont(font_manager.getResource(BASE_ROMFS_PATH+"fonts/roboto.ttf"));
    import_info.setMsg(gui_ptr->language_file.getValue("press_x_import"));
    export_info.attachChild(&import_info);
    import_info.setPosition(0, export_info.getSize().y + 10);

    exit_info.setFont(font_manager.getResource(BASE_ROMFS_PATH+"fonts/roboto.ttf"));
    exit_info.setMsg(gui_ptr->language_file.getValue("press_b_exit"));
    import_info.attachChild(&exit_info);
    exit_info.setPosition(0, import_info.getSize().y + 10);

    app_title.setFont(font_manager.getResource(BASE_ROMFS_PATH+"fonts/roboto.ttf"));
    app_title.setMsg(APP);
    app_title.setPosition( (gui_ptr->win.getSize().x / 2) - (app_title.getSize().x /2), 25 );
    scene.addToLayer(&app_title, 0);



    //creating the current account
    sn::Account account(sn::Account::CURRENT_ACCOUNT);
    if( !account.isValid() ) { //if the account is not logged
        initialization_result.setErrorNumber(ERR_ACCOUNT_UNLOGGED);
        initialization_result.setErrorDescription(ERR_ACCOUNT_UNLOGGED);
        return;
    }

    //setting the inputs
    std::vector<sn::InputSignal> signals;
    sn::InputEvent event_b(sn::InputEvent::BUTTON_PRESSED, KEY_B);
    sn::Signal signal_b("EXIT");
    signals.push_back(std::make_pair(event_b, signal_b));

    sn::InputEvent event_x(sn::InputEvent::BUTTON_PRESSED, KEY_X);
    sn::Signal signal_x("IMPORT");
    signals.push_back(std::make_pair(event_x, signal_x));

    sn::InputEvent event_y(sn::InputEvent::BUTTON_PRESSED, KEY_Y);
    sn::Signal signal_y("EXPORT");
    signals.push_back(std::make_pair(event_y, signal_y));

    sn::InputEvent event_l(sn::InputEvent::BUTTON_PRESSED, KEY_MINUS);
    sn::Signal signal_l("LEFT");
    signals.push_back(std::make_pair(event_l, signal_l));

    sn::InputEvent event_r(sn::InputEvent::BUTTON_PRESSED, KEY_PLUS);
    sn::Signal signal_r("RIGHT");
    signals.push_back(std::make_pair(event_r, signal_r));

    setInputSignal(signals);

    //getting all the savefiles
    std::vector<sn::SaveFile> temp_save_vector;
    res = account.getAllSaveFiles(temp_save_vector);
    if( !res ) {
        initialization_result.setErrorNumber(ERR_GET_SAVEFILE);
        initialization_result.setErrorDescription(res.getErrorDescription());
        return;
    }

    //converting the savefiles to full fledged svitch savefiles
    for(auto it = temp_save_vector.begin(); it < temp_save_vector.end(); it++)
        savefiles.push_back(SvitchSaveFile(*it));

    //writing the name of first save on screen
    if( savefiles.empty() ) {
        game_title.setMsg(gui_ptr->language_file.getValue("no_save"));
        game_title.setPosition( (gui_ptr->win.getSize().x / 2) - (game_title.getSize().x /2), (gui_ptr->win.getSize().y / 2) - (game_title.getSize().y / 2) );

        game_author.setMsg(gui_ptr->language_file.getValue("press_b_exit"));
        game_author.setPosition( (game_title.getSize().x / 2) - (game_author.getSize().x / 2), game_title.getSize().y + 10 );
    }

    else {
        buildTitleInfo();
        scene.addToLayer(&arrow_info, 0);
    }
}

void MainState::buildTitleInfo() {
    game_title.setMsg(savefiles[save_selected].getGameName());
    game_title.setPosition( (gui_ptr->win.getSize().x / 2) - (game_title.getSize().x /2), (gui_ptr->win.getSize().y / 2) - (game_title.getSize().y / 2) );

    game_author.setMsg(savefiles[save_selected].getGameAuthor());
    game_author.setPosition( (game_title.getSize().x / 2) - (game_author.getSize().x / 2), game_title.getSize().y + 10 );
}

void MainState::onNotify(const sn::Signal& theSignal) {
    if( theSignal.getName() == "EXIT" ) requestToExit();

    if( theSignal.getName() == "RIGHT" && !savefiles.empty() && save_selected < savefiles.size() - 1 ) emitSignal(sn::Signal("SCROLL_RIGHT"));
    if( theSignal.getName() == "SCROLL_RIGHT" ) { save_selected++; buildTitleInfo(); }

    if( theSignal.getName() == "LEFT" && !savefiles.empty() && save_selected > 0 ) emitSignal(sn::Signal("SCROLL_LEFT"));
    if( theSignal.getName() == "SCROLL_LEFT" ) { save_selected--; buildTitleInfo(); }

    if( theSignal.getName() == "EXPORT" ) export_svi();
    if( theSignal.getName() == "IMPORT" ) import_svi();
}

void MainState::export_svi() {
    char temp_buffer[256];

    std::string path = BASE_PATH + itoa(savefiles[save_selected].getTitleID(), temp_buffer, 16) + std::string(".svi");

    sn::Result res = savefiles[save_selected].extractToSVI(path);
    std::string result_str;
    if( res ) result_str = gui_ptr->language_file.getValue("extract_success") + " " + path;
    else result_str = gui_ptr->language_file.getValue("extract_failed") + " " + std::string(itoa(res.getErrorNumber(), temp_buffer, 10)) + "-" + std::string(itoa(res.getErrorDescription(), temp_buffer, 10));

    ResultState* res_state = new ResultState(gui_ptr, result_str);
    gui_ptr->addState(res_state);
}

void MainState::import_svi() {
    ImportState* import_state = new ImportState(gui_ptr, savefiles[save_selected]);
    gui_ptr->addState(import_state);
}
