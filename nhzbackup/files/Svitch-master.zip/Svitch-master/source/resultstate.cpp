#include "resultstate.hpp"
#include "options.hpp"

ResultState::ResultState(sn::Gui* theGui, const std::string& theString) : State(theGui) {
    //setting the inputs
    std::vector<sn::InputSignal> signals;
    sn::InputEvent event(sn::InputEvent::BUTTON_PRESSED, KEY_A);
    sn::Signal signal("EXIT");
    signals.push_back(std::make_pair(event, signal));

    setInputSignal(signals);

    //writing the string
    text.setFont(font_manager.getResource(BASE_ROMFS_PATH+"fonts/roboto.ttf"));
    text.setMsg(theString);
    scene.addToLayer(&text, 0);
    text.setPosition( (gui_ptr->win.getSize().x / 2) - (text.getSize().x /2), (gui_ptr->win.getSize().y / 2) - (text.getSize().y / 2) );

    press_a.setFont(font_manager.getResource(BASE_ROMFS_PATH+"fonts/roboto.ttf"));
    press_a.setMsg(gui_ptr->language_file.getValue("press_a_continue"));
    scene.addToLayer(&press_a, 0);
    press_a.setPosition( (text.getGlobalPosition().x) + (text.getSize().x / 2) - (press_a.getSize().x /2), 600 );
}

void ResultState::onNotify(const sn::Signal& theSignal) {
    if( theSignal.getName() == "EXIT" ) requestToExit();
}

