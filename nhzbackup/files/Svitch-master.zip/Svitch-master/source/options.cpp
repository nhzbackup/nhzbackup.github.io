#include "options.hpp"

#ifdef EMULATOR
std::string BASE_PATH("sdmc:/svitch/");
std::string BASE_ROMFS_PATH(BASE_PATH + "romfs/");
#else
std::string BASE_PATH("sdmc:/svitch/");
std::string BASE_ROMFS_PATH(BASE_PATH + "romfs/");
#endif

std::string APP_NAME("Svitch");
std::string APP_VERSION("0.1.1");
std::string APP(APP_NAME+" "+APP_VERSION);
