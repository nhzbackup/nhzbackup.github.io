#include "gui.hpp"
#include "mainstate.hpp"
#include "errorstate.hpp"
#include "result.hpp"

int main() {
    sn::Gui gui; //our gui
    sn::Result result; //here we'll store the program initialization result
    MainState* main_state = new MainState(&gui); //software initialization

    //if the initialization failed
    if( !(result = main_state->getInitializationResult()) ) {
        ErrorState* error_state = new ErrorState(&gui, result);
        gui.setFirstState(error_state); //we show the error state
    }

    //otherwise we show the regular main_state
    else gui.setFirstState(main_state);

    gui.run(); //running the gui
}
