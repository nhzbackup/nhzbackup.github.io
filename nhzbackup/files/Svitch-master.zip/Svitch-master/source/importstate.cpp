#include "importstate.hpp"

#include "options.hpp"
#include "resultstate.hpp"

ImportState::ImportState(sn::Gui* theGui, const SvitchSaveFile& theSaveFile) : sn::State(theGui), savefile(theSaveFile) {
    //variable initialization
    save_selected = 0;

    //texts initialization
    no_importing.setFont(font_manager.getResource(BASE_ROMFS_PATH+"fonts/roboto.ttf"));
    no_importing.setCharacterSize(20);
    no_importing.setMsg(gui_ptr->language_file.getValue("no_importing")+" "+savefile.getGameName());
    no_importing.setPosition( (gui_ptr->win.getSize().x / 2) - (no_importing.getSize().x /2), 500 );

    importing_for.setFont(font_manager.getResource(BASE_ROMFS_PATH+"fonts/roboto.ttf"));
    importing_for.setCharacterSize(20);
    importing_for.setMsg(gui_ptr->language_file.getValue("importing_for")+" "+savefile.getGameName());
    importing_for.setPosition( (gui_ptr->win.getSize().x / 2) - (importing_for.getSize().x /2), 150 );

    file_found.setFont(font_manager.getResource(BASE_ROMFS_PATH+"fonts/roboto.ttf"));
    file_found.setCharacterSize(25);

    file_info.setFont(font_manager.getResource(BASE_ROMFS_PATH+"fonts/roboto.ttf"));
    file_info.setCharacterSize(25);

    game_author.setFont(font_manager.getResource(BASE_ROMFS_PATH+"fonts/roboto.ttf"));
    game_author.setCharacterSize(35);

    game_title.setFont(font_manager.getResource(BASE_ROMFS_PATH+"fonts/roboto.ttf"));
    game_title.setCharacterSize(35);
    game_title.attachChild(&game_author);
    game_title.attachChild(&file_info);
    game_title.attachChild(&file_found);

    scene.addToLayer(&game_title, 0);

    arrow_info.setFont(font_manager.getResource(BASE_ROMFS_PATH+"fonts/roboto.ttf"));
    arrow_info.setMsg(gui_ptr->language_file.getValue("press_arrow_scroll_files"));
    arrow_info.setPosition(100, 600);

    import_info.setFont(font_manager.getResource(BASE_ROMFS_PATH+"fonts/roboto.ttf"));
    import_info.setMsg(gui_ptr->language_file.getValue("press_a_import"));
    arrow_info.attachChild(&import_info);
    import_info.setPosition(0, arrow_info.getSize().y + 10);

    exit_info.setFont(font_manager.getResource(BASE_ROMFS_PATH+"fonts/roboto.ttf"));
    exit_info.setMsg(gui_ptr->language_file.getValue("press_b_undo"));
    import_info.attachChild(&exit_info);
    exit_info.setPosition(0, import_info.getSize().y + 10);

    //setting the inputs
    std::vector<sn::InputSignal> signals;
    sn::InputEvent event_b(sn::InputEvent::BUTTON_PRESSED, KEY_B);
    sn::Signal signal_b("UNDO");
    signals.push_back(std::make_pair(event_b, signal_b));

    sn::InputEvent event_a(sn::InputEvent::BUTTON_PRESSED, KEY_A);
    sn::Signal signal_a("IMPORT");
    signals.push_back(std::make_pair(event_a, signal_a));

    sn::InputEvent event_l(sn::InputEvent::BUTTON_PRESSED, KEY_MINUS);
    sn::Signal signal_l("LEFT");
    signals.push_back(std::make_pair(event_l, signal_l));

    sn::InputEvent event_r(sn::InputEvent::BUTTON_PRESSED, KEY_PLUS);
    sn::Signal signal_r("RIGHT");
    signals.push_back(std::make_pair(event_r, signal_r));

    setInputSignal(signals);

    //getting all the savefiles
    SvitchSaveFile::getAllSVIInPath(savefiles_folder, BASE_PATH);

    //writing the name of first save on screen
    if( savefiles_folder.empty() ) {
        game_title.setMsg(gui_ptr->language_file.getValue("no_save") + " in " + BASE_PATH);
        game_title.setPosition( (gui_ptr->win.getSize().x / 2) - (game_title.getSize().x /2), (gui_ptr->win.getSize().y / 2) - (game_title.getSize().y / 2) );

        game_author.setMsg(gui_ptr->language_file.getValue("press_b_undo"));
        game_author.setPosition( (game_title.getSize().x / 2) - (game_author.getSize().x / 2), game_title.getSize().y + 10 );
    }

    else {
        buildTitleInfo();
        scene.addToLayer(&arrow_info, 0);
        scene.addToLayer(&importing_for, 0);
    }
}

void ImportState::buildTitleInfo() {
    scene.detachFromLayer(&no_importing, 0);

    game_title.setMsg(savefiles_folder[save_selected].getGameName());
    game_title.setPosition( (gui_ptr->win.getSize().x / 2) - (game_title.getSize().x /2), (gui_ptr->win.getSize().y / 2) - (game_title.getSize().y / 2) );

    game_author.setMsg(savefiles_folder[save_selected].getGameAuthor());
    game_author.setPosition( (game_title.getSize().x / 2) - (game_author.getSize().x / 2), game_title.getSize().y + 10 );

    file_info.setMsg(savefiles_folder[save_selected].getSVIPath());
    file_info.setPosition( (game_title.getSize().x / 2) - (file_info.getSize().x / 2), -file_info.getSize().y - 20  );

    file_found.setMsg(gui_ptr->language_file.getValue("file_found"));
    file_found.setPosition( (game_title.getSize().x / 2) - (file_found.getSize().x / 2), file_info.getPosition().y -file_found.getSize().y - 25  );

    if( savefiles_folder[save_selected].getTitleID() != savefile.getTitleID() ) scene.addToLayer(&no_importing, 0);
}

void ImportState::onNotify(const sn::Signal& theSignal) {
    if( theSignal.getName() == "UNDO" ) requestToExit();

    if( theSignal.getName() == "RIGHT" && !savefiles_folder.empty() && save_selected < savefiles_folder.size() - 1 ) emitSignal(sn::Signal("SCROLL_RIGHT"));
    if( theSignal.getName() == "SCROLL_RIGHT" ) { save_selected++; buildTitleInfo(); }

    if( theSignal.getName() == "LEFT" && !savefiles_folder.empty() && save_selected > 0 ) emitSignal(sn::Signal("SCROLL_LEFT"));
    if( theSignal.getName() == "SCROLL_LEFT" ) { save_selected--; buildTitleInfo(); }

    if( theSignal.getName() == "IMPORT" && !savefiles_folder.empty() && savefiles_folder[save_selected].getTitleID() == savefile.getTitleID() ) emitSignal(sn::Signal("IMPORT_POSSIBLE"));
    if( theSignal.getName() == "IMPORT_POSSIBLE" ) import_svi();
}

void ImportState::import_svi() {
    char temp_buffer[256];

    sn::Result res = savefile.importFromSVI(savefiles_folder[save_selected].getSVIPath());
    std::string result_str;
    if( res ) result_str = gui_ptr->language_file.getValue("importing_succesful");
    else result_str = gui_ptr->language_file.getValue("importing_failed") + " " + std::string(itoa(res.getErrorNumber(), temp_buffer, 10)) + "-" + std::string(itoa(res.getErrorDescription(), temp_buffer, 10));

    requestToExit();
    ResultState* res_state = new ResultState(gui_ptr, result_str);
    gui_ptr->addState(res_state);
}
