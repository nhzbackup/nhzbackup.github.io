#include "svitchsavefile.hpp"

#include <sys/stat.h>
#include <fstream>
#include <dirent.h>
#include <unistd.h>
#include <iostream>

#include "options.hpp"

const std::string SvitchSaveFile::HEADER_NAME = "svitch_homebrew_header.svh"; //more complicated than it needs to be, but at least we are safe we don't have any conflict
const std::string SvitchSaveFile::TITLE_ID_STR = "id";
const std::string SvitchSaveFile::GAME_STR = "game";
const std::string SvitchSaveFile::AUTHOR_STR = "author";
const std::string SvitchSaveFile::CRC_STR = "crc";
const std::string SvitchSaveFile::EXTRACTED_WITH_STR = "extracted_with";

SvitchSaveFile::SvitchSaveFile(const sn::SaveFile& theSaveFile) : sn::SaveFile(theSaveFile) {
    is_on_sd = false;
    crc = 0;
}

SvitchSaveFile::SvitchSaveFile(const u64 theTitleID) : sn::SaveFile(theTitleID) {
    is_on_sd = false;
    crc = 0;
}

SvitchSaveFile::SvitchSaveFile(const std::string theSVIPath) {
    crc = 0;
    is_on_sd = true;
    svi_path = theSVIPath;

    //we will now extract our headerfile into a string and read its information
    size_t header_size = 0;
    char* buffer;
    if( (buffer = (char*)mz_zip_extract_archive_file_to_heap(theSVIPath.c_str(), HEADER_NAME.c_str(), &header_size, 0)) == NULL ) { is_valid = false; return; }

    std::string str_buffer;
    str_buffer.append(buffer, header_size);

    delete [] buffer;

    //searching the title id into the header
    std::size_t str_pos = str_buffer.find(TITLE_ID_STR);
    if( str_pos == std::string::npos ) { is_valid = false; return; }
    std::size_t content_pos = str_pos + TITLE_ID_STR.size() + 1;
    std::size_t newline_pos = str_buffer.find("\n", content_pos); //we search for a newline AFTER the separator
    if( newline_pos == std::string::npos ) setTitleID(std::atoi(str_buffer.substr(content_pos, std::string::npos).c_str()));
    else setTitleID(std::atoi(str_buffer.substr(content_pos, newline_pos-content_pos).c_str()));

    //searching the game name into the header
    str_pos = str_buffer.find(GAME_STR);
    if( str_pos == std::string::npos ) { is_valid = false; return; }
    content_pos = str_pos + GAME_STR.size() + 1;
    newline_pos = str_buffer.find("\n", content_pos); //we search for a newline AFTER the separator
    if( newline_pos == std::string::npos ) setGameName(str_buffer.substr(content_pos, std::string::npos));
    else setGameName(str_buffer.substr(content_pos, newline_pos-content_pos));

    //searching the game author into the header
    str_pos = str_buffer.find(AUTHOR_STR);
    if( str_pos == std::string::npos ) { is_valid = false; return; }
    content_pos = str_pos + AUTHOR_STR.size() + 1;
    newline_pos = str_buffer.find("\n", content_pos); //we search for a newline AFTER the separator
    if( newline_pos == std::string::npos ) setGameAuthor(str_buffer.substr(content_pos, std::string::npos));
    else setGameAuthor(str_buffer.substr(content_pos, newline_pos-content_pos));

    //searching the crc into the header (not correctly implemented
    /*str_pos = str_buffer.find(CRC_STR);
    if( str_pos == std::string::npos ) { is_present = false; return; }
    content_pos = str_pos + CRC_STR.size() + 1;
    newline_pos = str_buffer.find("\n", content_pos); //we search for a newline AFTER the separator
    if( newline_pos == std::string::npos ) crc = std::atoi(str_buffer.substr(content_pos, std::string::npos).c_str());
    else crc = std::atoi(str_buffer.substr(content_pos, newline_pos-content_pos).c_str());*/

    is_valid = true;
}

sn::Result SvitchSaveFile::commit() const {
    if( !is_on_sd ) return sn::SaveFile::commit();
    else return sn::Result(sn::Result::SUCCESS);
}

std::string SvitchSaveFile::getMountPoint() const {
    if( is_on_sd ) return getMountName();
    else return SaveFile::getMountPoint();
}

sn::Result SvitchSaveFile::isPresent(const sn::Account& theAccount) const {
    if( is_on_sd ) return sn::Result(ERR_NOT_FOUND, ERR_NOT_FOUND); //this function returns if this savefile is present on nand, if it is on sd it returns false
    else return SaveFile::isPresent(theAccount);
}

bool SvitchSaveFile::isValid() const {
    if( is_on_sd ) return is_valid;
    else return isPresent(sn::Account::CURRENT_ACCOUNT);
}

sn::Result SvitchSaveFile::extractSVIToFile(const std::string& thePath) {
    //initializing an archive
    mz_zip_archive archive;
    mz_zip_zero_struct(&archive);
    if( !mz_zip_reader_init_file(&archive, svi_path.c_str(), 0) ) return sn::Result(ERR_SVI_INVALID, ERR_SVI_INVALID);

    //creating the directory
    if( mkdir(thePath.c_str(), 0x777) != 0 ) return Result(ERR_CREATE_DIRECTORY);

    unsigned int file_num = mz_zip_reader_get_num_files(&archive);

    //scrolling through it
    for(unsigned int i = 0; i < file_num; i++) {
        mz_zip_reader_extract_iter_state* it = mz_zip_reader_extract_iter_new(&archive, i, 0); //creating the iterator
        const int MAX_FILE_SIZE = 2*10^7; //hoping that 20mb will always be enough
        char* file_buffer = new char[MAX_FILE_SIZE];
        size_t file_size = mz_zip_reader_extract_iter_read(it, file_buffer, MAX_FILE_SIZE); //reading the file

        //if it is a directory we create it
        if( it->file_stat.m_is_directory ) {
            if( mkdir((thePath+it->file_stat.m_filename).c_str(), 0x777) != 0 ) {
                delete [] file_buffer;
                mz_zip_reader_extract_iter_free(it);
                return sn::Result(ERR_CREATE_DIRECTORY, ERR_CREATE_DIRECTORY);
            }
        }

        //if it is a file we write it to disk
        else {
            if( std::string(it->file_stat.m_filename) != HEADER_NAME ) {
                std::ofstream stream((thePath+it->file_stat.m_filename).c_str(), std::ios::out | std::ios::binary);
                if( !stream.is_open() ) {
                    delete [] file_buffer;
                    mz_zip_reader_extract_iter_free(it);
                    return sn::Result(ERR_OPEN_STREAM, ERR_OPEN_STREAM);
                }

                stream.write(file_buffer, file_size);
                if( !stream.good() ) {
                    delete [] file_buffer;
                    mz_zip_reader_extract_iter_free(it);
                    return sn::Result(ERR_WRITE_FILE, ERR_WRITE_FILE);
                }
            }
        }

        delete [] file_buffer;
        mz_zip_reader_extract_iter_free(it);
    }

    mz_zip_end(&archive);
    return sn::Result(sn::Result::SUCCESS);
}

sn::Result SvitchSaveFile::mount(const std::string& theMountName, const sn::Account& theAccount) {
    if( isMounted() ) return sn::Result(sn::Result::SUCCESS); //if already mounted why even bother?

    if( is_on_sd ) {
        //we sanitize the path (if it does not end with a slash, we add it)
        std::string sanitized_path = theMountName;
        if( theMountName.find_last_of("/") != theMountName.size()-1 ) sanitized_path.append("/");

        sn::Result res = extractSVIToFile(sanitized_path);
        if( res ) setMountName(sanitized_path);
        return res;
    }

    else return SaveFile::mount(theMountName, theAccount);
}

sn::Result SvitchSaveFile::deleteAllFiles(const std::string& thePath) {
    //just deleting files
    DIR* d = opendir(thePath.c_str()); // open the path
    if( d == NULL ) return sn::Result(ERR_READ_ITERATOR, ERR_READ_ITERATOR); // if was not able return
    dirent* dir; // for the directory entries

    //just deleting files
    Result res;
    while ((dir = readdir(d)) != NULL) {
        if( dir->d_type == DT_DIR )
            if( !(res = deleteAllFiles(thePath+"/"+std::string(dir->d_name))) )
                return res;

        if(dir-> d_type == DT_REG) {
            #ifndef EMULATOR
            if( remove((thePath+"/"+std::string(dir->d_name)).c_str()) != 0 ) {

                closedir(d); return sn::Result(ERR_DELETE_FILE, ERR_DELETE_FILE);

            }
            #endif
        }
    }

    closedir(d);
    return sn::Result(sn::Result::SUCCESS);
}

sn::Result SvitchSaveFile::deleteAllFolders(const std::string& thePath) {
    //just deleting folders
    DIR* d = opendir(thePath.c_str()); // open the path
    if( d == NULL ) return sn::Result(ERR_READ_ITERATOR, ERR_READ_ITERATOR); // if was not able return
    dirent* dir; // for the directory entries

    //just deleting folders
    Result res;

    while((dir = readdir(d)) != NULL) {
        if( dir->d_type == DT_DIR ) {
            if( !(res = deleteAllFolders(thePath+"/"+std::string(dir->d_name))) )
                return res;
        }
    }

    #ifndef EMULATOR
    if( rmdir(thePath.c_str()) != 0 ) return sn::Result(ERR_DELETE_DIRECTORY);
    #endif
    closedir(d);
    return sn::Result(sn::Result::SUCCESS);
}

sn::Result SvitchSaveFile::unmount() {
    if( !isMounted() ) return sn::Result(sn::Result::SUCCESS); //if already unmounted why even bother?

    if( is_on_sd ) {
        sn::Result res = wipeFromFileSystem();
        if( !res ) return res;

        setMountName("");
        return sn::Result(sn::Result::SUCCESS);
    }

    else return SaveFile::unmount();
}

sn::Result SvitchSaveFile::extractPathToSVI(mz_zip_archive& theArchive, const std::string& theSourcePath, const std::string& theDestinationPath, const std::string& theIterator) {
    sn::Result res;

    DIR* d = opendir(theSourcePath.c_str()); // open the path
    if( d == NULL ) return sn::Result(ERR_READ_ITERATOR, ERR_READ_ITERATOR); // if was not able return
    dirent* dir; // for the directory entries

    char fake_buffer; //i could probably pass nullptr but who knows...

    while((dir = readdir(d)) != NULL) {
        if( dir->d_type == DT_DIR ) {

            if( !mz_zip_writer_add_mem(&theArchive, (theIterator+std::string(dir->d_name)+"/").c_str(), &fake_buffer, 0, MZ_DEFAULT_COMPRESSION) ) return sn::Result(ERR_CREATE_DIRECTORY);
            if( !(res = extractPathToSVI(theArchive, theSourcePath+std::string(dir->d_name)+"/", theDestinationPath, theIterator+std::string(dir->d_name)+"/")) ) return res;
        }

        else if( dir->d_type == DT_REG ) {
            #ifdef EMULATOR
            if( dir->d_name != sn::SaveFile::SNITCH_SAVEHEADER_NAME )
            #endif // EMULATOR
            if( !mz_zip_writer_add_file(&theArchive, (theIterator+dir->d_name).c_str(), (theSourcePath+dir->d_name).c_str(), nullptr, 0, MZ_DEFAULT_COMPRESSION) ) return sn::Result(ERR_WRITE_FILE);

        }
    }

    closedir(d);
    return sn::Result(sn::Result::SUCCESS);
}

sn::Result SvitchSaveFile::extractToSVI(const std::string& thePath) {
    if( is_on_sd ) { //if it already is on SVI we can just do a bit per bit copy to extract it :D
        std::ifstream input_stream(svi_path.c_str(), std::ios::in | std::ios::binary); //opening input stream
        std::ofstream output_stream(thePath.c_str(), std::ios::out | std::ios::binary);

        if( !input_stream.is_open() || !output_stream.is_open() ) return sn::Result(ERR_OPEN_STREAM, ERR_OPEN_STREAM);

        //retrieving size
        input_stream.seekg(0, std::ios::end);
        std::ifstream::pos_type size = input_stream.tellg();
        input_stream.seekg(0);

        char* buffer = new char[size];

        input_stream.read(buffer, size);
        output_stream.write(buffer, size);

        delete [] buffer;

        if( !input_stream.good() || !output_stream.good() ) return sn::Result(ERR_WRITE_FILE);

        return sn::Result(sn::Result::SUCCESS);

    }

    else {
        //choosing a temporary mount point name
        unsigned int temp_index = 0;
        bool already_exists;
        std::string mount_point;

        do {
            already_exists = false;
            DIR* d = opendir("sdmc:/"); // open the path
            if( d == NULL ) return sn::Result(ERR_READ_ITERATOR, ERR_READ_ITERATOR); // if was not able return
            dirent* dir; // for the directory entries
            mount_point = "TEMP_" + std::to_string(temp_index);

            while ((dir = readdir(d)) != NULL) {
                if( dir->d_name ==  mount_point ) already_exists = true;
            }

            closedir(d);
            temp_index++;
        }while(already_exists);

        sn::Result res = mount(mount_point);
        if( !res ) return res;

        //creating the archive and writing the header
        char temp_buffer[1024];
        std::string str_header =    TITLE_ID_STR + "=" + std::string(itoa(getTitleID(), temp_buffer, 10)) + "\n" +
                                    GAME_STR + "=" + getGameName() + "\n" +
                                    AUTHOR_STR + "=" + getGameAuthor() + "\n" +
                                    EXTRACTED_WITH_STR + "=" + APP;

        char* archive_buffer; //here we will store the archive to write it on disk
        size_t archive_buffer_size;
        mz_zip_archive archive;
        mz_zip_zero_struct(&archive);

        if( !mz_zip_writer_init_heap(&archive, 0, str_header.size()) ) { unmount(); mz_zip_end(&archive); return sn::Result(ERR_WRITE_FILE); }
        if( !mz_zip_writer_add_mem(&archive, HEADER_NAME.c_str(), str_header.c_str(), str_header.size(), MZ_DEFAULT_COMPRESSION) ) { unmount(); mz_zip_end(&archive); return sn::Result(ERR_WRITE_FILE); }

        res = extractPathToSVI(archive, getMountPoint(), thePath);
        if( !res ) { unmount(); mz_zip_end(&archive); return res; }

        if( !mz_zip_writer_finalize_heap_archive(&archive, ((void**)(&archive_buffer)), &archive_buffer_size) ) { unmount(); mz_zip_end(&archive); return sn::Result(ERR_WRITE_FILE); }

        //writing the file to disk
        std::ofstream stream(thePath.c_str(), std::ios::out | std::ios::binary);
        if( !stream.is_open() ) { delete [] archive_buffer; unmount(); mz_zip_end(&archive); return sn::Result(ERR_OPEN_STREAM); }
        stream.write(archive_buffer, archive_buffer_size);
        if( !stream.good() ) { delete [] archive_buffer; unmount(); mz_zip_end(&archive); return sn::Result(ERR_WRITE_FILE); }

        delete [] archive_buffer;
        mz_zip_end(&archive);
        return unmount();
    }
}

sn::Result SvitchSaveFile::wipeFromFileSystem() {
    sn::Result res = deleteAllFiles(getMountPoint());
    if( !res ) return res;

    res = deleteAllFolders(getMountPoint());
    if( !res ) return res;

    return sn::Result(sn::Result::SUCCESS);
}

sn::Result SvitchSaveFile::importFromSVI(const std::string& thePath) {
    if( is_on_sd ) { //if trying to import an svi we just copy that one into this
        sn::Result res = unmount(); //unmount for safety reasons
        if( !res ) return res;

        SvitchSaveFile temp(thePath);
        if( !temp.isValid() ) sn::Result(ERR_SVI_INVALID);

        res = temp.extractToSVI(svi_path);
        if( !res ) return res;

        *this = temp; //may cause problems :D
        return sn::Result(sn::Result::SUCCESS);
    }

    else {
        //choosing a temporary mount point name
        unsigned int temp_index = 0;
        bool already_exists;
        std::string mount_point;

        do {
            already_exists = false;
            DIR* d = opendir("sdmc:/"); // open the path
            if( d == NULL ) return sn::Result(ERR_READ_ITERATOR, ERR_READ_ITERATOR); // if was not able return
            dirent* dir; // for the directory entries
            mount_point = "TEMP_" + std::to_string(temp_index);

            while ((dir = readdir(d)) != NULL) {
                if( dir->d_name ==  mount_point ) already_exists = true;
            }

            closedir(d);
            temp_index++;
        }while(already_exists);

        sn::Result res = mount(mount_point);
        if( !res ) return res;

        //wiping the save
        res = wipeFromFileSystem();
        if( !res ) return res;

        //initializing an archive
        mz_zip_archive archive;
        mz_zip_zero_struct(&archive);
        if( !mz_zip_reader_init_file(&archive, thePath.c_str(), 0) ) return sn::Result(ERR_OPEN_STREAM, ERR_OPEN_STREAM);

        unsigned int file_num = mz_zip_reader_get_num_files(&archive);

        //scrolling through it
        for(unsigned int i = 0; i < file_num; i++) {
            mz_zip_reader_extract_iter_state* it = mz_zip_reader_extract_iter_new(&archive, i, 0); //creating the iterator
            const int MAX_FILE_SIZE = 2*10^7; //hoping that 20mb will always be enough
            char* file_buffer = new char[MAX_FILE_SIZE];
            size_t file_size = mz_zip_reader_extract_iter_read(it, file_buffer, MAX_FILE_SIZE); //reading the file

            //if it is a directory we create it
            if( it->file_stat.m_is_directory ) {
                if( mkdir((getMountPoint()+it->file_stat.m_filename).c_str(), 0x777) != 0 ) {
                    delete [] file_buffer;
                    mz_zip_reader_extract_iter_free(it);
                    return sn::Result(ERR_CREATE_DIRECTORY, ERR_CREATE_DIRECTORY);
                }
            }

            //if it is a file we write it to disk
            else {
                if( std::string(it->file_stat.m_filename) != HEADER_NAME ) {
                    std::ofstream stream((getMountPoint()+it->file_stat.m_filename).c_str(), std::ios::out | std::ios::binary);
                    if( !stream.is_open() ) {
                        delete [] file_buffer;
                        mz_zip_reader_extract_iter_free(it);
                        return sn::Result(ERR_OPEN_STREAM, ERR_OPEN_STREAM);
                    }

                    stream.write(file_buffer, file_size);
                    if( !stream.good() ) {
                        delete [] file_buffer;
                        mz_zip_reader_extract_iter_free(it);
                        return sn::Result(ERR_WRITE_FILE, ERR_WRITE_FILE);
                    }
                }
            }

            delete [] file_buffer;
            mz_zip_reader_extract_iter_free(it);
        }

        mz_zip_end(&archive);
        return commit();
    }
}

sn::Result SvitchSaveFile::getAllSVIInPath(std::vector<SvitchSaveFile>& theBuffer, const std::string& thePath) {
    //we sanitize the path (if it does not end with a slash, we add it)
    std::string sanitized_path = thePath;
    if( thePath.find_last_of("/") != thePath.size()-1 ) sanitized_path.append("/");

    theBuffer.clear();
    sn::Result res;

    DIR* d = opendir(sanitized_path.c_str()); // open the path
    if( d == NULL ) return sn::Result(ERR_READ_ITERATOR, ERR_READ_ITERATOR); // if was not able return
    dirent* dir; // for the directory entries

    while((dir = readdir(d)) != NULL) {
        if( dir->d_type == DT_REG ) {
            std::string file_name = dir->d_name;
            std::size_t point_pos = file_name.find_last_of(".");
            std::string file_extension;
            if( point_pos != std::string::npos ) file_extension = file_name.substr(point_pos + 1, std::string::npos); //searching for the .svi extension

            if( file_extension == "svi" ) theBuffer.push_back(SvitchSaveFile(sanitized_path+dir->d_name));
        }
    }

    return sn::Result(sn::Result::SUCCESS);
}
