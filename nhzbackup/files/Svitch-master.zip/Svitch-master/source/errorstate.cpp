#include "errorstate.hpp"

#include <iostream>

ErrorState::ErrorState(sn::Gui* theGui, sn::Result theError) : State(theGui) {
    //setting the inputs
    std::vector<sn::InputSignal> signals;
    sn::InputEvent event(sn::InputEvent::BUTTON_PRESSED, KEY_A);
    sn::Signal signal("EXIT");
    signals.push_back(std::make_pair(event, signal));

    setInputSignal(signals);

    //writing the error
    gui_ptr->win.setConsole(true);
    std::cout << "Initialization failed with error: " << theError.getErrorNumber() << "-" << theError.getErrorDescription() << ".\n";
    std::cout << "Press A to exit.";
}

void ErrorState::onNotify(const sn::Signal& theSignal) {
    if( theSignal.getName() == "EXIT" ) requestToExit();
}
