#ifndef _RESULTSTATE_HPP_
#define _RESULTSTATE_HPP_

#include <string>

#include "state.hpp"
#include "text.hpp"

class ResultState : public sn::State {
    private:
        sn::Text text;
        sn::Text press_a;

    public:
        ResultState(sn::Gui* theGui, const std::string& theString);

        virtual void onNotify(const sn::Signal& theSignal);
};

#endif // _ERRORSTATE_HPP_

