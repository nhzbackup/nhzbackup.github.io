#ifndef _IMPORTSTATE_HPP_
#define _IMPORTSTATE_HPP_

#include <vector>

#include "state.hpp"
#include "gui.hpp"
#include "svitchsavefile.hpp"
#include "result.hpp"
#include "text.hpp"

/*the import state of this software*/

class ImportState : public sn::State {
    private:
        SvitchSaveFile savefile; //the savefile we are importing into
        std::vector<SvitchSaveFile> savefiles_folder; //all the .svi files we find in the svitch folder
        unsigned int save_selected;

        sn::Text importing_for;
        sn::Text no_importing;

        sn::Text file_found;
        sn::Text file_info;
        sn::Text game_title;
        sn::Text game_author;

        sn::Text import_info;
        sn::Text arrow_info;
        sn::Text exit_info;

        void buildTitleInfo();
        void import_svi();

    public:
        ImportState(sn::Gui* theGui, const SvitchSaveFile& theSaveFile);

        virtual void onNotify(const sn::Signal& theSignal);
};

#endif //_IMPORTSTATE_HPP_
