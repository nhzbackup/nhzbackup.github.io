#ifndef _OPTIONS_HPP_
#define _OPTIONS_HPP_

#include <string>

#ifdef EMULATOR
extern std::string BASE_PATH;
extern std::string BASE_ROMFS_PATH;
#else
extern std::string BASE_PATH;
extern std::string BASE_ROMFS_PATH;
#endif

extern std::string APP_NAME;
extern std::string APP_VERSION;
extern std::string APP;

#endif // _OPTIONS_HPP_
