#ifndef _MAINSTATE_HPP_
#define _MAINSTATE_HPP_

#include <vector>

#include "state.hpp"
#include "gui.hpp"
#include "account.hpp"
#include "svitchsavefile.hpp"
#include "result.hpp"
#include "text.hpp"

/*the principal state of this software*/

class MainState : public sn::State {
    private:
        sn::Result initialization_result; //the result of the initialization
        std::vector<SvitchSaveFile> savefiles; //all the savefiles in the system
        unsigned int save_selected;

        sn::Text game_title;
        sn::Text game_author;

        sn::Text arrow_info;
        sn::Text export_info;
        sn::Text import_info;
        sn::Text exit_info;

        sn::Text app_title;

        void buildTitleInfo();
        void export_svi();
        void import_svi();

    public:
        enum Error {
            ERR_ACCOUNT_UNLOGGED = 1,
            ERR_GET_SAVEFILE,
            ERR_LANGUAGE_FILE
        };

        MainState(sn::Gui* theGui);

        sn::Result getInitializationResult() const { return initialization_result; }
        virtual void onNotify(const sn::Signal& theSignal);
};

#endif //_MAINSTATE_HPP_
