#ifndef _SVITCHSAVEFILE_HPP_
#define _SVITCHSAVEFILE_HPP_

#include "savefile.hpp"
#include "miniz.h"

/*an extension of the Snitch's SaveFile class to implement some function needed for this software, see Nintendo Switch savefile
documentation for further information*/

class SvitchSaveFile : public sn::SaveFile {
    private:
        bool is_on_sd; //whether or not this savefile is on nand (ready to be exported) or on sd (ready to be imported)
        bool is_valid; //helper member that will store if a savefile is present or not on the sdmc
        std::string svi_path;
        mz_ulong crc; //the crc of the sd file, calculated with miniz library

        static const std::string HEADER_NAME;
        static const std::string TITLE_ID_STR;
        static const std::string GAME_STR;
        static const std::string AUTHOR_STR;
        static const std::string CRC_STR;
        static const std::string EXTRACTED_WITH_STR;

        sn::Result extractSVIToFile(const std::string& thePath); //extract an svi to a path (used in the mount function)
        sn::Result deleteAllFiles(const std::string& thePath); //unmounts the save file if it is in svi format (to be called iteratively)
        sn::Result deleteAllFolders(const std::string& thePath); //unmounts the save file if it is in svi format (to be called iteratively)
        sn::Result extractPathToSVI(mz_zip_archive& theArchive, const std::string& theSourcePath, const std::string& theDestinationPath, const std::string& theIterator=""); //extract an entire folder to the svi file

    public:
        enum Error {
            ERR_SVI_INVALID = 50, //starting from 50 to differentiate them from the codes returned by the snitch library (sigh)
            ERR_OPEN_STREAM,
            ERR_CREATE_DIRECTORY,
            ERR_WRITE_FILE,
            ERR_READ_ITERATOR,
            ERR_DELETE_FILE,
            ERR_DELETE_DIRECTORY,
            ERR_NOT_MOUNTED,
        };

        SvitchSaveFile() = delete; //IT IS BETTER TO NOT CALL THIS DIRECTLY
        SvitchSaveFile(const u64 theTitleID); //call this if you need to load the save file from inside the systen
        SvitchSaveFile(const std::string theSVIPath); //or call this if you need to load the save from an svi file from the sd
        SvitchSaveFile(const sn::SaveFile& theSaveFile); //this will convert a normal snitch's library savefile to a glorified svitch savefile


        bool isOnSD() const { return is_on_sd; } //NOTE THAT THIS DOES NOT ASSURE THAT THE FILE ACTUALLY EXISTS ON THE FILESYSTEM
        std::string getSVIPath() const { return svi_path; }
        //mz_ulong getCRC() const { return crc; } currently not implemented
        sn::Result isPresent(const sn::Account& theAccount = sn::Account(sn::Account::CURRENT_ACCOUNT)) const;
        bool isValid() const;
        std::string getMountPoint() const;
        sn::Result mount(const std::string& theMountName, const sn::Account& theAccount = sn::Account(sn::Account::CURRENT_ACCOUNT)); //mounts the save file for this title at the specified mount name (READ ONLY IF THIS IS ON SDD)
        sn::Result unmount(); //currently doesn't work for SVI files if launched in yuzu
        sn::Result extractToSVI(const std::string& thePath);
        sn::Result importFromSVI(const std::string& thePath);
        sn::Result commit() const;
        sn::Result wipeFromFileSystem();
        static sn::Result getAllSVIInPath(std::vector<SvitchSaveFile>& theBuffer, const std::string& thePath);

};

#endif // _SVITCHSAVEFILE_HPP_
