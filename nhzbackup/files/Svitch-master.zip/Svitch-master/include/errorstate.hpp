#ifndef _ERRORSTATE_HPP_
#define _ERRORSTATE_HPP_

#include "state.hpp"
#include "result.hpp"

class ErrorState : public sn::State {
    public:
        ErrorState(sn::Gui* theGui, sn::Result theError);

        virtual void onNotify(const sn::Signal& theSignal);
};

#endif // _ERRORSTATE_HPP_
