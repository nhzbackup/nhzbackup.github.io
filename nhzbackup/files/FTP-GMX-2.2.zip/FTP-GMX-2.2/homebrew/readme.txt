FTP-GMX 2.2

Install:
1) Drag the "FTP-GMX-2.2" folder into the "3ds" folder of your SD card
2) Run "FTP-GMX 2.2" application through the homebrew launcher